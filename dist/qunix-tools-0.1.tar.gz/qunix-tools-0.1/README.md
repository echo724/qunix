# QuNix
QuNix is a project of Unix like python programs by using Qiskit and Quantum Circuit with following Unix Philosophy

- Both program use **MicroQiskit** [https://github.com/qiskit-community/MicroQiskit](https://github.com/qiskit-community/MicroQiskit)

## Program Lists

### Quantum Circuuit Builder(QCB)

### Alea

# Slack Connection

# Credit

MicroQiskit(https://github.com/qiskit-community/MicroQiskit)
